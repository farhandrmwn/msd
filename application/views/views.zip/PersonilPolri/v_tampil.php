<?php $this->load->view('partials/header') ?>

 <div class="header bg-gradient-orange pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            
          </div>
          
         
        </div>
      </div>
    </div>
 <div class="container-fluid mt--6">

        <div class="card mt-0">
        <div class="card-header">
      <h1 class="mb-0"> PERSONIL  POLRI</h1>
           <div class="text-right">
                <a href="<?php  echo base_url('RD_polri/pilih') ?>" class="btn btn-sm btn-warning">Kembali</a>
              </div>
        </div>


        <div class="card-body">
            <a href="<?php echo base_url()?>/PersonilPolri/tambah" class="btn btn-primary" role="button">Tambah Data</a>
            <a href="<?php echo base_url('RD_polri/excel'); ?>" class='btn btn-success'>Export Data</a>
            <div class="table-responsive text-nowrap">
                <table class="table table-bordered text-center mt-4">
                  <thead>
                
                    <tr>
                        <th>No</th>
                        <th>NRP</th>
                        <th>Nama</th>
                        <th>Pangkat</th>
                        <th>Jabatan</th>
                        <th>Alamat Rumdin</th>
                        <th>Jumlah POT</th>
                        <th>Aksi</th>
                     </tr>
                  </thead>
                  <tbody>
                  <?php 
                        $no = 1;
                        foreach($PersonilPolri as $p){ 
                    ?>
                    <tr>
                      <th scope="row"><?php echo $no++ ?></th>
                      <td><?php echo $p->nrp ?></td>
                      <td><?php echo $p->nama ?></td>
                      <td><?php echo $p->pangkat ?></td>
                      <td><?php echo $p->jabatan ?></td>
                      <td><?php echo $p->alamat ?></td>
                      <td><?php echo $p->pot ?></td>
                      <td>
                         <a href="<?= base_url('personilpolri/edit/'.$p->id) ?>" class="btn btn-primary"><i class="glyphicon glyphicon-pencil"></i> Edit</a>
                        <a href="<?= base_url('personilpolri/hapus/'.$p->id) ?>" class="btn btn-danger"><i class="glyphicon glyphicon-remove"></i> Remove</a>
                      </td>
                    </tr>
                    <?php } ?>
                  </tbody>
                 
                </table>
            </div>
        </div>
        </div>
    </div>


<?php $this->load->view('partials/footer') ?>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.colVis.min.js"></script>
<script>
   $(document).ready(function() {
      $('#example').DataTable();
  } );
</script>