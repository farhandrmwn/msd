<?php $this->load->view('partials/header') ?>

<?php $this->load->view('partials/rumdin') ?>


 

 <div class="mb-5 py-8">  

 </div>


<?php $this->load->view('partials/footer') ?>
